package org.swecha.speechrecognition;

import java.util.HashMap;
import java.util.Map;

public class TeluguSoundex {

    private static final Map<Character, Character> teluguToPhoneticMap = new HashMap<>();

    static {
        // Define mappings from Telugu characters to phonetic codes
        // Note: This is a simplified example and may need more comprehensive mapping
        teluguToPhoneticMap.put('క', '1');
        teluguToPhoneticMap.put('ఖ', '1');
        teluguToPhoneticMap.put('గ', '1');
        teluguToPhoneticMap.put('ఘ', '1');
        teluguToPhoneticMap.put('చ', '2');
        teluguToPhoneticMap.put('ఛ', '2');
        teluguToPhoneticMap.put('జ', '2');
        teluguToPhoneticMap.put('ఝ', '2');
        teluguToPhoneticMap.put('ట', '3');
        teluguToPhoneticMap.put('ఠ', '3');
        teluguToPhoneticMap.put('డ', '3');
        teluguToPhoneticMap.put('ఢ', '3');
        teluguToPhoneticMap.put('త', '4');
        teluguToPhoneticMap.put('థ', '4');
        teluguToPhoneticMap.put('ద', '4');
        teluguToPhoneticMap.put('ధ', '4');
        teluguToPhoneticMap.put('ప', '5');
        teluguToPhoneticMap.put('ఫ', '5');
        teluguToPhoneticMap.put('బ', '5');
        teluguToPhoneticMap.put('భ', '5');
        teluguToPhoneticMap.put('స', '6');
        teluguToPhoneticMap.put('శ', '6');
        teluguToPhoneticMap.put('ష', '6');
        teluguToPhoneticMap.put('హ', '7');
        teluguToPhoneticMap.put('య', '8');
        teluguToPhoneticMap.put('ర', '9');
        teluguToPhoneticMap.put('ల', 'A');
        teluguToPhoneticMap.put('వ', 'B');
        teluguToPhoneticMap.put('మ', 'C');
        teluguToPhoneticMap.put('న', 'D');
    }

    public static void main(String[] args) {
        String str1 = "తెలుగు";
        String str2 = "తలుగు";

        String soundex1 = getSoundex(str1);
        String soundex2 = getSoundex(str2);

        if (soundex1.equals(soundex2)) {
            System.out.println("The strings sound similar.");
        } else {
            System.out.println("The strings do not sound similar.");
        }
    }

    public static String getSoundex(String s) {
        char[] x = s.toCharArray();
        char firstLetter = x[0];

        // Convert letters to numeric code
        for (int i = 0; i < x.length; i++) {
            x[i] = teluguToPhoneticMap.getOrDefault(x[i], '0');
        }

        // Remove duplicates
        StringBuilder output = new StringBuilder().append(firstLetter);
        for (int i = 1; i < x.length; i++) {
            if (x[i] != x[i - 1] && x[i] != '0') {
                output.append(x[i]);
            }
        }

        // Pad with 0s or truncate to 4 characters
        output.append("0000");
        return output.substring(0, 4);
    }
}

