package org.swecha.speechrecognition;

import static org.swecha.speechrecognition.TeluguSoundex.getSoundex;

import android.content.Context;
import android.content.Intent;
import android.media.AudioFormat;
import android.media.AudioRecord;
import android.media.MediaRecorder;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.HandlerThread;
//import android.service.chooser.ChooserAction;
import android.os.Looper;
import android.util.Log;
import android.util.Pair;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import org.apache.commons.text.similarity.LevenshteinDistance;
import org.pytorch.IValue;
import org.pytorch.Module;
import org.pytorch.Tensor;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.FloatBuffer;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.time.Duration;
import java.time.Instant;

import org.pytorch.LiteModuleLoader;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.speech.RecognizerIntent;
import android.speech.tts.TextToSpeech;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Random;

public class MainActivity extends AppCompatActivity implements Runnable, TextToSpeech.OnInitListener {
    private static final String TAG = MainActivity.class.getName();
    private Module module;
    private final static int REQUEST_RECORD_AUDIO = 13;
    private final static int AUDIO_LEN_IN_SECOND = 50;
    private final static int SAMPLE_RATE = 16000;
    private int RECORDING_LENGTH = SAMPLE_RATE * AUDIO_LEN_IN_SECOND;
    private final static String LOG_TAG = MainActivity.class.getSimpleName();
    private int mStart = 1;
    private HandlerThread mTimerThread;
    private Handler mTimerHandler;
    private boolean isRecognizing = false;
    private Instant startTime = Instant.now();
    private TextView sentenceTextView;
    private TextView translationTextView;
    private TextView spokenTextView;
    private Button speakButton;
    private Button playbackButton;
    private List<List<String>> sentences;
    private int currentSentenceIndex = 0;
    private TextToSpeech textToSpeech;
    private static final int REQUEST_CODE_SPEECH_INPUT = 1;
    private static final int PERMISSION_REQUEST_CODE = 2;
    private int correctCount = 0;
    private int errorCount = 0;
    private TextView correctCountTextView;
    private TextView errorCountTextView;
    private Random random = new Random();
    private ScoreDbHelper dbHelper;
    private Handler mainHandler;
    private SpacedRepetitionSystem srs;
    private Runnable mRunnable = new Runnable() {
        @Override
        public void run() {
            mTimerHandler.postDelayed(mRunnable, 1000);

            MainActivity.this.runOnUiThread(
                    () -> {
                        speakButton.setText(String.format("Listening - %ds left", AUDIO_LEN_IN_SECOND - mStart));
                        mStart += 1;
                    });
        }
    };

    @Override
    protected void onDestroy() {
        stopTimerThread();
        if (textToSpeech != null) {
            textToSpeech.stop();
            textToSpeech.shutdown();
        }
        super.onDestroy();
        dbHelper.close();
    }

    @Override
    public void onInit(int status) {
        if (status == TextToSpeech.SUCCESS) {
            Locale teluguLocale = new Locale("te", "IN");  // Telugu (India)
            int result = textToSpeech.setLanguage(teluguLocale);
            if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                Toast.makeText(this, "Text-to-Speech language not supported.", Toast.LENGTH_SHORT).show();
                playbackButton.setEnabled(false);
            }
        } else {
            Toast.makeText(this, "Text-to-Speech initialization failed.", Toast.LENGTH_SHORT).show();
            playbackButton.setEnabled(false);
        }
    }

    protected void stopTimerThread() {
        mTimerThread.quitSafely();
        try {
            mTimerThread.join();
            mTimerThread = null;
            mTimerHandler = null;
            mStart = 1;
        } catch (InterruptedException e) {
            Log.e(TAG, "Error on stopping background thread", e);
        }
    }

    private void startSpeechRecognition() {
        if (!isRecognizing) {
            isRecognizing = true;
            Thread thread = new Thread(MainActivity.this);
            startTime = Instant.now();
            thread.start();
            mTimerThread = new HandlerThread("Timer");
            mTimerThread.start();
            mTimerHandler = new Handler(mTimerThread.getLooper());
            mTimerHandler.postDelayed(mRunnable, 1000);
        } else {
            isRecognizing = false;
        }
        speakButton.setText(String.format("Listening - %ds left", AUDIO_LEN_IN_SECOND));
    }

    private List<List<String>> loadSentencesFromFile() {
//        List<List<String>> sentences = new ArrayList<>();
//        try (InputStream inputStream = getResources().openRawResource(R.raw.sentences);
//             BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream, StandardCharsets.UTF_8))) {
//
//            String line;
//            while ((line = reader.readLine()) != null) {
//                String[] parts = line.split(",", 3);
//                List<String> sentence = new ArrayList<>();
//
//                for (int i = 0; i < 3; i++) {
//                    if (i < parts.length) {
//                        sentence.add(parts[i].trim());
//                    } else {
//                        sentence.add("");
//                    }
//                }
//
//                sentences.add(sentence);
//            }
//        } catch (IOException e) {
//            e.printStackTrace();
//        }
//        return sentences;
        List<List<String>> sentences = new ArrayList<>();
        try (InputStream inputStream = getResources().openRawResource(R.raw.sentences);
             BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream))) {

            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",", 3);
                if (parts.length == 3) {
                    List<String> sentence = new ArrayList<>();
                    sentence.add(parts[0].trim()); // transliteration
                    sentence.add(parts[1].trim()); // english
                    sentence.add(parts[2].trim()); // telugu
                    sentences.add(sentence);
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return sentences;
    }
    private void initializeSpacedRepetitionSystem() {
        List<Integer> existingIndexes = srs.getAllSentenceIndexes();
        for (int i = 0; i < sentences.size(); i++) {
            if (!existingIndexes.contains(i)) {
                srs.addItem(i);
            }
        }
    }
//    private void displayNextSentence() {
//        if (currentSentenceIndex < sentences.size()) {
//            List<String> sentence = sentences.get(currentSentenceIndex);
//            String telugu = sentence.get(0);
//            String translation = sentence.get(1);
//
//            sentenceTextView.setText(telugu);
//            translationTextView.setText(translation);
//            spokenTextView.setText("");
//        } else {
////            sentenceTextView.setText("Congratulations! You've completed all sentences.");
////            speakButton.setEnabled(false);
////            playbackButton.setEnabled(false);
////            spokenTextView.setText("");
//        }
//    }
private void displayNextSentence() {
    int nextSentenceIndex = srs.getNextSentenceIndex();
    if (nextSentenceIndex != -1) {
        currentSentenceIndex = nextSentenceIndex;
    } else {
        currentSentenceIndex = random.nextInt(sentences.size());
    }

    final List<String> sentence = sentences.get(currentSentenceIndex);
    mainHandler.post(new Runnable() {
        @Override
        public void run() {
            sentenceTextView.setText(sentence.get(2)); // Telugu
            translationTextView.setText(sentence.get(1)); // English
            spokenTextView.setText("");
        }
    });
}

    private void displayRandomSentence() {
        mainHandler.post(new Runnable() {
            @Override
            public void run() {
        if (!sentences.isEmpty()) {
            currentSentenceIndex = random.nextInt(sentences.size());
            List<String> sentence = sentences.get(currentSentenceIndex);
            String telugu = sentence.get(0);
            String translation = sentence.get(1);

            sentenceTextView.setText(telugu);
            translationTextView.setText(translation);
            spokenTextView.setText("");
        } else {
            sentenceTextView.setText("No sentences available.");
            speakButton.setEnabled(false);
            playbackButton.setEnabled(false);
        }
            }
        });
    }

    private void updateScoreDisplay() {
        mainHandler.post(new Runnable() {
            @Override
            public void run() {
        correctCountTextView.setText("Correct: " + correctCount);
        errorCountTextView.setText("Errors: " + errorCount);
                Log.d(TAG, "run: "+correctCount);
        dbHelper.updateScores(correctCount, errorCount);
            }
        });
    }
    private void loadScoresFromDatabase() {
        Pair<Integer, Integer> scores = dbHelper.getScores();
        correctCount = scores.first;
        errorCount = scores.second;
        Log.d(TAG, "loadScoresFromDatabase: "+errorCount);
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mainHandler = new Handler(Looper.getMainLooper());

        sentenceTextView = findViewById(R.id.sentenceTextView);
        spokenTextView = findViewById(R.id.spokenTextView);
        translationTextView = findViewById(R.id.translationTextView);
        speakButton = findViewById(R.id.speakButton);
        playbackButton = findViewById(R.id.playbackButton);
        correctCountTextView = findViewById(R.id.correctCountTextView);
        errorCountTextView = findViewById(R.id.errorCountTextView);
        if (module == null) {
            module = LiteModuleLoader.load(assetFilePath(getApplicationContext(), "swecha.ptl"));
        }
        srs = new SpacedRepetitionSystem(this);
        sentences = loadSentencesFromFile();
        initializeSpacedRepetitionSystem();
        displayNextSentence();
        updateScoreDisplay();
//        sentences = loadSentencesFromFile();
//        displayRandomSentence();
//        updateScoreDisplay();
        dbHelper = new ScoreDbHelper(this);
        Log.d(TAG, "onCreatexxxxxxxxxxxxxxxxxxx: "+dbHelper);
        loadScoresFromDatabase();
        textToSpeech = new TextToSpeech(this, this);

        speakButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (ContextCompat.checkSelfPermission(MainActivity.this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                    ActivityCompat.requestPermissions(MainActivity.this, new String[]{Manifest.permission.RECORD_AUDIO}, PERMISSION_REQUEST_CODE);
                } else {
                    startSpeechRecognition();
                }
            }
        });

        playbackButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                speakSentence();
            }
        });
        requestMicrophonePermission();
    }

    private void requestMicrophonePermission() {
        requestPermissions(
                new String[]{Manifest.permission.RECORD_AUDIO}, REQUEST_RECORD_AUDIO);
    }

    private void speakSentence() {
        String toSpeak = sentences.get(currentSentenceIndex).get(2);
        textToSpeech.speak(toSpeak, TextToSpeech.QUEUE_FLUSH, null, null);
    }

    private String assetFilePath(Context context, String assetName) {
        File file = new File(context.getFilesDir(), assetName);
        if (file.exists() && file.length() > 0) {
            return file.getAbsolutePath();
        }

        try (InputStream is = context.getAssets().open(assetName)) {
            try (OutputStream os = Files.newOutputStream(file.toPath())) {
                byte[] buffer = new byte[4 * 1024];
                int read;
                while ((read = is.read(buffer)) != -1) {
                    os.write(buffer, 0, read);
                }
                os.flush();
            }
            return file.getAbsolutePath();
        } catch (IOException e) {
            Log.e(TAG, assetName + ": " + e.getLocalizedMessage());
        }
        return null;
    }

    private void showTranslationResult(String result) {
//        mTextView.setText(result);
        Log.d(TAG, "showTranslationResult: "+result);
        spokenTextView.setText(result);
    }
//    private void compareSpeech(String spokenText){
//        String currentSentence = sentences.get(currentSentenceIndex).get(2).trim().toLowerCase();
//        String cleanedSpokenText = spokenText.replaceAll("[\\p{Punct}\\s]+", " ");
//        String cleanedCurrentSentence = currentSentence.replaceAll("[\\p{Punct}\\s]+", " ");
//        int distance = new LevenshteinDistance().apply(cleanedSpokenText, cleanedCurrentSentence);
//        int similarityThreshold = 5; // Adjust this threshold as needed
//        if (distance <= similarityThreshold) {
//            textToSpeech.speak("Congrats. Try the next sentence.", TextToSpeech.QUEUE_FLUSH, null, null);
//            currentSentenceIndex++;
//            correctCount=correctCount+1;
//            displayRandomSentence();
//        } else {
//            errorCount=errorCount+1;
//            textToSpeech.speak("Incorrect. Please try again.", TextToSpeech.QUEUE_FLUSH, null, null);
//        }
//        updateScoreDisplay();
//    }
private void compareSpeech(final String spokenText) {
    final String currentSentence = sentences.get(currentSentenceIndex).get(0).trim().toLowerCase(); // Transliteration
    final String cleanedSpokenText = spokenText.replaceAll("[\\p{Punct}\\s]+", " ");
    final String cleanedCurrentSentence = currentSentence.replaceAll("[\\p{Punct}\\s]+", " ");
    final int distance = new LevenshteinDistance().apply(cleanedSpokenText, cleanedCurrentSentence);
    final int similarityThreshold = 5; // Adjust this threshold as needed

    mainHandler.post(new Runnable() {
        @Override
        public void run() {
            int quality;
            if (distance <= similarityThreshold) {
                correctCount++;
                quality = 5; // Perfect response
                textToSpeech.speak("Correct! Try the next sentence.", TextToSpeech.QUEUE_FLUSH, null, null);
            } else if (distance <= similarityThreshold * 2) {
                correctCount++;
                quality = 4; // Correct response after a hesitation
                textToSpeech.speak("Good! Try the next sentence.", TextToSpeech.QUEUE_FLUSH, null, null);
            } else if (distance <= similarityThreshold * 3) {
                quality = 3; // Correct response recalled with serious difficulty
                textToSpeech.speak("Almost there. Try the next sentence.", TextToSpeech.QUEUE_FLUSH, null, null);
            } else {
                errorCount++;
                quality = 0; // Incorrect response; the correct one remembered
                textToSpeech.speak("Incorrect. The correct answer was: " + currentSentence + ". Let's try the next sentence.", TextToSpeech.QUEUE_FLUSH, null, null);
            }

            srs.updateItem(currentSentenceIndex, quality);
            updateScoreDisplay();
            displayNextSentence();
        }
    });
}
    public void run() {
        android.os.Process.setThreadPriority(android.os.Process.THREAD_PRIORITY_AUDIO);

        int bufferSize = AudioRecord.getMinBufferSize(SAMPLE_RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT);
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            // TODO: Consider calling
            //    ActivityCompat#requestPermissions
            // here to request the missing permissions, and then overriding
            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
            //                                          int[] grantResults)
            // to handle the case where the user grants the permission. See the documentation
            // for ActivityCompat#requestPermissions for more details.
            return;
        }
        AudioRecord record = new AudioRecord(MediaRecorder.AudioSource.DEFAULT, SAMPLE_RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT,
                bufferSize);

        if (record.getState() != AudioRecord.STATE_INITIALIZED) {
            Log.e(LOG_TAG, "Audio Record can't initialize!");
            return;
        }
        record.startRecording();

        long shortsRead = 0;
        int recordingOffset = 0;
        short[] audioBuffer = new short[bufferSize / 2];
        short[] recordingBuffer = new short[SAMPLE_RATE * 50];
//        assuming max record size of 50 secs
//        short[] recordingBuffer = new short[RECORDING_LENGTH];
        Instant endTime = Instant.now();

        // Calculate the duration between start and end time in seconds
        long secondsPassed = Duration.between(startTime, endTime).getSeconds();
        while (isRecognizing || secondsPassed>50) {
            int numberOfShort = record.read(audioBuffer, 0, audioBuffer.length);
            shortsRead += numberOfShort;
            System.arraycopy(audioBuffer, 0, recordingBuffer, recordingOffset, numberOfShort);
            recordingOffset += numberOfShort;
            endTime = Instant.now();
            secondsPassed = Duration.between(startTime, endTime).getSeconds();
        }
        // Record the end time
        RECORDING_LENGTH = SAMPLE_RATE * (int)secondsPassed;
        record.stop();
        record.release();
        stopTimerThread();

        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                speakButton.setText("Recognizing...");
            }
        });

        float[] floatInputBuffer = new float[RECORDING_LENGTH];

        // feed in float values between -1.0f and 1.0f by dividing the signed 16-bit inputs.
        for (int i = 0; i < RECORDING_LENGTH; ++i) {
            floatInputBuffer[i] = recordingBuffer[i] / (float)Short.MAX_VALUE;
        }

        final String result = recognize(floatInputBuffer);
        compareSpeech(result);
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                showTranslationResult(result);
                speakButton.setEnabled(true);
                speakButton.setText("Start");
            }
        });
    }

    private String recognize(float[] floatInputBuffer) {


        double swechainput[] = new double[RECORDING_LENGTH];
        for (int n = 0; n < RECORDING_LENGTH; n++)
            swechainput[n] = floatInputBuffer[n];

        FloatBuffer inTensorBuffer = Tensor.allocateFloatBuffer(RECORDING_LENGTH);
        for (double val : swechainput)
            inTensorBuffer.put((float)val);

        Tensor inTensor = Tensor.fromBlob(inTensorBuffer, new long[]{1, RECORDING_LENGTH});
        final String result = module.forward(IValue.from(inTensor)).toStr();

        return result;
    }
}