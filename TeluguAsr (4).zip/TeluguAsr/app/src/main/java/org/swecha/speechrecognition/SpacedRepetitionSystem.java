package org.swecha.speechrecognition;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class SpacedRepetitionSystem extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "SpacedRepetitionDB";
    private static final int DATABASE_VERSION = 1;

    private static final String TABLE_ITEMS = "items";
    private static final String COLUMN_ID = "id";
    private static final String COLUMN_SENTENCE_INDEX = "sentence_index";
    private static final String COLUMN_EASINESS = "easiness";
    private static final String COLUMN_REPETITIONS = "repetitions";
    private static final String COLUMN_INTERVAL = "interval";
    private static final String COLUMN_NEXT_PRACTICE = "next_practice";

    public SpacedRepetitionSystem(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String CREATE_ITEMS_TABLE = "CREATE TABLE " + TABLE_ITEMS + "("
                + COLUMN_ID + " INTEGER PRIMARY KEY,"
                + COLUMN_SENTENCE_INDEX + " INTEGER,"
                + COLUMN_EASINESS + " REAL,"
                + COLUMN_REPETITIONS + " INTEGER,"
                + COLUMN_INTERVAL + " INTEGER,"
                + COLUMN_NEXT_PRACTICE + " INTEGER)";
        db.execSQL(CREATE_ITEMS_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_ITEMS);
        onCreate(db);
    }

    public void addItem(int sentenceIndex) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_SENTENCE_INDEX, sentenceIndex);
        values.put(COLUMN_EASINESS, 2.5);
        values.put(COLUMN_REPETITIONS, 0);
        values.put(COLUMN_INTERVAL, 0);
        values.put(COLUMN_NEXT_PRACTICE, new Date().getTime());
        db.insert(TABLE_ITEMS, null, values);
        db.close();
    }

    public void updateItem(int sentenceIndex, int quality) {
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.query(TABLE_ITEMS, null, COLUMN_SENTENCE_INDEX + " = ?",
                new String[]{String.valueOf(sentenceIndex)}, null, null, null);

        if (cursor.moveToFirst()) {
            @SuppressLint("Range") int id = cursor.getInt(cursor.getColumnIndex(COLUMN_ID));
            @SuppressLint("Range") double easiness = cursor.getDouble(cursor.getColumnIndex(COLUMN_EASINESS));
            @SuppressLint("Range") int repetitions = cursor.getInt(cursor.getColumnIndex(COLUMN_REPETITIONS));
            @SuppressLint("Range") int interval = cursor.getInt(cursor.getColumnIndex(COLUMN_INTERVAL));

            // Calculate new easiness factor
            easiness = Math.max(1.3, easiness + 0.1 - (5.0 - quality) * (0.08 + (5.0 - quality) * 0.02));

            // Update repetitions and interval
            if (quality >= 3) {
                repetitions++;
                if (repetitions == 1) {
                    interval = 1;
                } else if (repetitions == 2) {
                    interval = 6;
                } else {
                    interval = (int) Math.round(interval * easiness);
                }
            } else {
                repetitions = 0;
                interval = 1;
            }

            // Calculate next practice date
            long nextPractice = new Date().getTime() + interval * 24 * 60 * 60 * 1000L;

            ContentValues values = new ContentValues();
            values.put(COLUMN_EASINESS, easiness);
            values.put(COLUMN_REPETITIONS, repetitions);
            values.put(COLUMN_INTERVAL, interval);
            values.put(COLUMN_NEXT_PRACTICE, nextPractice);

            db.update(TABLE_ITEMS, values, COLUMN_ID + " = ?", new String[]{String.valueOf(id)});
        }

        cursor.close();
        db.close();
    }

    @SuppressLint("Range")
    public int getNextSentenceIndex() {
        SQLiteDatabase db = this.getReadableDatabase();
        String query = "SELECT " + COLUMN_SENTENCE_INDEX + " FROM " + TABLE_ITEMS +
                " WHERE " + COLUMN_NEXT_PRACTICE + " <= ? ORDER BY " + COLUMN_NEXT_PRACTICE + " ASC LIMIT 1";
        Cursor cursor = db.rawQuery(query, new String[]{String.valueOf(new Date().getTime())});

        int sentenceIndex = -1;
        if (cursor.moveToFirst()) {
            sentenceIndex = cursor.getInt(cursor.getColumnIndex(COLUMN_SENTENCE_INDEX));
        }

        cursor.close();
        db.close();
        return sentenceIndex;
    }

    @SuppressLint("Range")
    public List<Integer> getAllSentenceIndexes() {
        List<Integer> indexes = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_ITEMS, new String[]{COLUMN_SENTENCE_INDEX}, null, null, null, null, null);

        if (cursor.moveToFirst()) {
            do {
                indexes.add(cursor.getInt(cursor.getColumnIndex(COLUMN_SENTENCE_INDEX)));
            } while (cursor.moveToNext());
        }

        cursor.close();
        db.close();
        return indexes;
    }
}
