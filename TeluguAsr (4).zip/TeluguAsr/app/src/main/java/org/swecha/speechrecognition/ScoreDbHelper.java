package org.swecha.speechrecognition;

import android.annotation.SuppressLint;
import android.content.Context;
import android.database.sqlite.SQLiteOpenHelper;
import android.database.sqlite.SQLiteDatabase;
import android.content.ContentValues;
import android.database.Cursor;
import android.util.Log;
import android.util.Pair;

public class ScoreDbHelper extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "ScoreDatabase";
    private static final int DATABASE_VERSION = 1;

    private static final String TABLE_SCORES = "scores";
    private static final String COLUMN_ID = "id";
    private static final String COLUMN_CORRECT = "correct";
    private static final String COLUMN_ERRORS = "errors";
    private final static String LOG_TAG = ScoreDbHelper.class.getSimpleName();
    private static final String CREATE_SCORES_TABLE = "CREATE TABLE " + TABLE_SCORES + "("
            + COLUMN_ID + " INTEGER PRIMARY KEY,"
            + COLUMN_CORRECT + " INTEGER,"
            + COLUMN_ERRORS + " INTEGER)";

    public ScoreDbHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(CREATE_SCORES_TABLE);
        // Initialize with default values
        ContentValues values = new ContentValues();
        values.put(COLUMN_ID, 1);
        values.put(COLUMN_CORRECT, 0);
        values.put(COLUMN_ERRORS, 0);
        db.insert(TABLE_SCORES, null, values);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_SCORES);
        onCreate(db);
    }

    public void updateScores(int correct, int errors) {
        Log.d(LOG_TAG, "updateScores: "+correct);
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_CORRECT, correct);
        values.put(COLUMN_ERRORS, errors);
        db.update(TABLE_SCORES, values, COLUMN_ID + " = ?", new String[]{"1"});
    }

    @SuppressLint("Range")
    public Pair<Integer, Integer> getScores() {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_SCORES, new String[]{COLUMN_CORRECT, COLUMN_ERRORS},
                COLUMN_ID + " = ?", new String[]{"1"}, null, null, null);
        int correct = 0;
        int errors = 0;
        if (cursor.moveToFirst()) {
            correct = cursor.getInt(cursor.getColumnIndex(COLUMN_CORRECT));
            errors = cursor.getInt(cursor.getColumnIndex(COLUMN_ERRORS));
        }
        cursor.close();
        return new Pair<>(correct, errors);
    }
}